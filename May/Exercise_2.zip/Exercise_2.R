library(dplyr)
dat<-read.csv("msleep.csv")
View(dat)
class(dat)
Primates <- filter(dat, order=="Primates")
View(Primates)
nrow(Primates)
class(dat)
PrimatesVals <- select(Primates, sleep_total)
class(PrimatesVals)
PrimatesVals <- filter(dat, order=="Primates") %>% select(sleep_total)
class(PrimatesVals)
?unlist
PrimatesVals <- filter(dat, order=="Primates") %>% select(sleep_total) %>% unlist
mean(PrimatesVals)
class(PrimatesVals)
?summarize
PrimateVals <- filter(dat, order=="Primates") %>% summarize(mean = mean(sleep_total), n = n())
PrimateVals


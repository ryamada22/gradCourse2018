dat<-read.csv("femaleMiceweights.csv")
View (dat)
dat
dat[12,2]
dat$Bodyweight
x<-dat$Bodyweight
x[11]
length(x)
mean(x[13:24])
set.seed(1)
?sample
sample(13:24, size=1)
x[16]
